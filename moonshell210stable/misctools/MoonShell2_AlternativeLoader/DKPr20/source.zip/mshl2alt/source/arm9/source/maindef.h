
#ifndef maindef_h
#define maindef_h

#define ROMTITLE "MoonShellExecute Soft reset"
//#define ROMVERSION "Ver0.6b"				//====== by Rudolph (2007/11/03)
//#define ROMVERSION "Ver0.6b4ak2"			//====== by kzat3 (2008/03/30)
#define ROMVERSION ""
#define ROMDATE ""__DATE__" "__TIME__" GMT+09:00"
#define ROMAUTHOR "Moonlight (Modified by Rudolph, kzat3)"
//#define ROMENV "DevKitARMr17 + libnds-20060201"
//#define ROMENV "DevKitARMr19b + libnds-20060719"
#define ROMENV "DevKitARMr20 + libnds-20070127 + libfat-20070127"

#endif

