
#define MULTIPLIER  int		/* type for fastest integer multiply */

#define DCTSIZE		    8	/* The basic DCT block is 8x8 samples */
#define DCTSIZE2	    64	/* DCTSIZE squared; # of elements in a block */
#define BITS_IN_JSAMPLE (8)

typedef signed short s16;
typedef signed long s32;

typedef s32 DCTELEM;		/* 16 or 32 bits is fine */
typedef s32 INT32;

#define DCT_IFAST_SUPPORTED

#define GLOBAL(type)		type

#define SHIFT_TEMPS
#define RIGHT_SHIFT(x,shft)	((x) >> (shft))
#define ISHIFT_TEMPS
#define IRIGHT_SHIFT(x,shft)	((x) >> (shft))

#include "jfdctfst.h"
#include "jidctfst.h"

